package Pennant.LearnHub.LearnHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnHubApplication.class, args);
	}

}
