package Pennant.LearnHub.LearnHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
